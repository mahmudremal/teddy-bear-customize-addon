<?php $_products = []; ?>
<body bgcolor="#e0f2f8" background="<?php echo esc_url(TEDDY_BEAR_CUSTOMIZE_ADDON_BUILD_IMG_URI . '/certificate_email_sky.jpg'); ?>" link="#133845" vlink="#133845" text="#4D4D4D" style="background-image: linear-gradient(182deg, #e0f2f8 70%, transparent 100%);font-family:Helvetica, Arial, sans-serif;font-size:12px;background-image:url(<?php echo esc_url(TEDDY_BEAR_CUSTOMIZE_ADDON_BUILD_IMG_URI . '/certificate_email_sky.jpg'); ?>);background-repeat:repeat;border: 1px solid #e0f2f8;margin:0;padding:0;" data-new-gr-c-s-check-loaded="14.1119.0" data-gr-ext-installed="">
  <table align="center" width="100%" cellpadding="0" cellspacing="0" style="width:100%; color: #4D4D4D;">
    <tbody>
      <tr>
      <!-- <td width="250">&nbsp;</td> -->
      <td>
        <table width="620" height="40" border="0" align="center" cellpadding="0" cellspacing="0" style="width:620px; height:20px;">
          <tbody>
            <tr>
              <td height="20" align="center" valign="middle" style="color:#266F8A; font-size:11px;">If you can't see this email, please <a style="color:#133845; text-decoration:underline;" href="#">follow this link</a> to preview emails and download attachments certificates.</td>
            </tr>
            <tr>
              <td width="620" height="178" align="center" valign="middle" style="color:#266F8A; font-size:11px;">
                <a href="<?php echo site_url('/'); ?>" target="_blank" style="display: block;">
                  <img src="<?php echo esc_url(TEDDY_BEAR_CUSTOMIZE_ADDON_BUILD_IMG_URI . '/certificate_email_header.png'); ?>" width="620" height="178" border="0">
                </a>
              </td>
            </tr>
          </tbody>
        </table>
        
        <table width="620" border="0" align="center" cellpadding="0" cellspacing="0">
          <tbody>
            <tr>
              <td height="42" colspan="3" align="center" valign="middle" style="font-size:20px; color:#FFFFFF; font-weight:400;">
                <!-- <img src="images/main-heading.png" width="620" height="41"> -->
                <p style="color: #fff;padding: 10px;border-radius: 15px;margin: auto;background-image: linear-gradient(359deg, #f6aa15 28%, transparent 121%);text-shadow: 0px 0px 3px #83704a;border: none;letter-spacing: 2px;">Find your teddies birth certifictaes below.</p>
              </td>
            </tr>
            <tr>
              <td height="27" colspan="3"><img src="<?php echo esc_url(TEDDY_BEAR_CUSTOMIZE_ADDON_BUILD_IMG_URI . '/certificate_email_spacer.gif'); ?>" width="20" height="27"></td>
            </tr>
          </tbody>
        </table>
        
        
        <table width="620" border="0" align="center" cellpadding="0" cellspacing="0">
          <tbody>
            <tr>
              <td height="13" colspan="7">
                <img src="<?php echo esc_url(TEDDY_BEAR_CUSTOMIZE_ADDON_BUILD_IMG_URI . '/certificate_email_box_border_top.png'); ?>" width="620" height="13">
              </td>
            </tr>
            <tr>
              <td width="13" background="https://www.mouseevent.com/themeforest/tfc/nl/images/dashed_border_left.png" bgcolor="#FFFFFF" style="background-image:url(https://www.mouseevent.com/themeforest/tfc/nl/images/dashed_border_left.png); background-repeat:repeat-y; width:13px;"><img src="<?php echo esc_url(TEDDY_BEAR_CUSTOMIZE_ADDON_BUILD_IMG_URI . '/certificate_email_spacer.gif'); ?>" width="13" height="20"></td>
              <td width="10" bgcolor="#FFFFFF">
                <img src="<?php echo esc_url(TEDDY_BEAR_CUSTOMIZE_ADDON_BUILD_IMG_URI . '/certificate_email_spacer.gif'); ?>" width="10" height="20">
              </td>
              <td height="15" align="left" valign="top" bgcolor="#FFFFFF">
                <span style="text-align:left; font-family:Helvetica, Arial, sans-serif; font-weight:normal; font-size:12px; line-height:15pt; color:#666666;">
                <?php esc_html_e('Congratulations on your purchase! Our teddy bear birth certificate is a special keepsake to commemorate your new teddy bear. We wish your teddy bear a lifetime of love and happiness! Please find the certificate attached.', 'teddybearsprompts'); ?>
                </span>
              </td>
              <td width="20" bgcolor="#FFFFFF">
                <img src="<?php echo esc_url(TEDDY_BEAR_CUSTOMIZE_ADDON_BUILD_IMG_URI . '/certificate_email_spacer.gif'); ?>" width="20" height="30">
              </td>
              <td width="10" bgcolor="#FFFFFF">
                <img src="<?php echo esc_url(TEDDY_BEAR_CUSTOMIZE_ADDON_BUILD_IMG_URI . '/certificate_email_spacer.gif'); ?>" width="10" height="20">
              </td>
              <td width="12" background="https://www.mouseevent.com/themeforest/tfc/nl/images/dashed_border_right.png" bgcolor="#FFFFFF" style="background-image:url(https://www.mouseevent.com/themeforest/tfc/nl/images/dashed_border_right.png); background-repeat:repeat-y; width:12px;">
                <img src="<?php echo esc_url(TEDDY_BEAR_CUSTOMIZE_ADDON_BUILD_IMG_URI . '/certificate_email_spacer.gif'); ?>" width="12" height="20">
              </td>
            </tr>
            <tr>
              <td height="13" colspan="7">
                <img src="<?php echo esc_url(TEDDY_BEAR_CUSTOMIZE_ADDON_BUILD_IMG_URI . '/certificate_email_box_border_bottom.png'); ?>" width="620" height="13">
              </td>
            </tr>
            <tr>
              <td height="29" colspan="7">
                <img src="<?php echo esc_url(TEDDY_BEAR_CUSTOMIZE_ADDON_BUILD_IMG_URI . '/certificate_email_spacer.gif'); ?>" alt="" width="20" height="29">
              </td>
            </tr>
          </tbody>
        </table>
        
      </td>
    </tr>
  </tbody></table>
  <table width="100%" height="190" border="0" cellspacing="0" cellpadding="0" background="<?php echo esc_url(TEDDY_BEAR_CUSTOMIZE_ADDON_BUILD_IMG_URI . '/certificate_email_bgloop.jpg'); ?>" style="background-image:url(<?php echo esc_url(TEDDY_BEAR_CUSTOMIZE_ADDON_BUILD_IMG_URI . '/certificate_email_bgloop.jpg'); ?>); background-repeat:repeat-x;">
    <tbody>
      <tr>
        <!-- <td width="250">&nbsp;</td> -->
          <td height="190" align="center" valign="top">
          <table width="624" border="0" cellspacing="0" cellpadding="0">
            <tbody>
              <tr>
                <td height="190" align="center" valign="top"><img src="<?php echo esc_url(TEDDY_BEAR_CUSTOMIZE_ADDON_BUILD_IMG_URI . '/certificate_email_footer.jpg'); ?>" width="624" height="190"></td>
              </tr>
            </tbody>
          </table>
        </td>
      </tr>
    </tbody>
  </table>
</body>